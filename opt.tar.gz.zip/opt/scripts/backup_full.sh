#!/bin/bash

# Ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 origen destino"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Validación de argumentos
ORIGEN="$1"
DESTINO="$2"

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe indicar origen y destino."
    echo "Use -help para más información."
    exit 1
fi

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El origen no existe."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El destino no existe."
    exit 1
fi

# Generar nombre de archivo con fecha
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

# Ejecutar backup
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"

echo "Backup de $ORIGEN guardado en $DESTINO/$NOMBRE"
